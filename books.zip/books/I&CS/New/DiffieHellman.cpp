//Assignment 3: Diffie Hellman Algorithm
//it a key agreement algorithm 
//Symetric key agreement is done through this 

#include<iostream>
#include<math.h>
using namespace std;

int cal_R(int p,int q,int a)
{
	int R=1;
	for(int i=0;i<a;i++)
	{
		R = R*q;
		R = R%p;
	}
	return R;
}

int cal_Rk(int p,int q,int S)
{
	int Rk = 1;
	for(int i=0;i<q;i++)
	{
		Rk = Rk * S;
		Rk = Rk % p;
	}
	return Rk;
}
long int power(int q,int a,int p)
{
	if (a == 1)
		return q;
	
	return ((long int)pow(q,a)%p);
}
int main()
{
	int p,q;
	cout<<"Enter p and q such that both are prime:\n";
	cin>>p>>q;
	
	int a;
	cout<<"Enter a which is chosen by Ramesh:\n";
	cin>>a;
	
	int b;
	cout<<"Enter b which is chosen by Suresh:\n";
	cin>>b;
	
	long int r = power(q,a,p);
	long int s = power(q,b,p);
	
	cout<<"The value of R is:"<<r<<endl;
	cout<<"The value of S is:"<<s<<endl;

	long int rk = power(s,a,p);
	long int sk = power(r,b,p);
	
	cout<<"The value of RK is:"<<rk<<endl;
	cout<<"The value of Sk is:"<<sk<<endl;

	
	if(rk == sk)
		cout<<"Key Agreement Done!"<<endl;
	else
		cout<<"Failed"<<endl;
	return 0;
}
