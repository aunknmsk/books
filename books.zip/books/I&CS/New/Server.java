package rsa;

import java.io.IOException;
import java.io.PrintStream;
import java.io.DataInputStream;

import java.net.ServerSocket;
import java.net.Socket;

import java.util.Scanner;


public class Server 
{

        public static long encrypt(int e, int n)
        {
            
            Scanner sc=new Scanner(System.in);
            System.out.println("\nEnter Plain text:");
            long M=sc.nextInt();
            long C=1;
            int i;
            for(i=0;i<e;i++)
            {
                C=C*M;
                C=C%n;
            }
            return C;
        }
	public static void main(String[] args) throws IOException, NullPointerException
	{
		
            ServerSocket server = new ServerSocket(2000);
            System.out.println("Server Started");
			
	    System.out.println("Waiting for Client");
			
	    Socket socket = server.accept();
	    System.out.println("Client Accepted");
            
            //Get public key
            System.out.println("Public Key Receieved");
            DataInputStream d1=new DataInputStream(socket.getInputStream());
            String str1=d1.readLine();
            DataInputStream d2=new DataInputStream(socket.getInputStream());
	    String str2=d2.readLine();
            
            //send the encrypted data to client
            long C= encrypt(Integer.parseInt(str1),Integer.parseInt(str2));
            System.out.println("\nSending encrypted msg....");
                       
            PrintStream ps1  = new PrintStream(socket.getOutputStream());
	    ps1.println(C);
            System.out.println("\nEncrypted msg sent....");
            socket.close();
           
	}
}

