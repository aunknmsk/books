package rsa;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.*;
import java.math.*;
import java.net.ServerSocket;

public class Client {	
        public static int cal_e(int phi)
        {   
            int e=2;
            while(e<phi)
            {
                if(gcd(e,phi)==1)
                    break;
                else e++;
            }
            return e;
        }
        
        static int gcd(int a, int b)
        {
            int r=a%b;
            while(r!=0)
            {
                a=b;
                b=r;
                r=a%b;
            }
            return b;         
        }
        
        public static int cal_d(int phi,int e)
        {   
            int d=1;
            while(((d*e)%phi)!=1)
            {
                d++;
            }
            return d;
        }
        
        public static long decrypt(int d, int n,long C)
        {  
            long m=1;
            int i;
            for(i=0;i<d;i++)
            {
                m=m*C;
                m=m%n;
            }
            return m;
        }
        
        public static int is_prime(int p)
        {
            int i;
            for(i=2;i<p;i++)
            {
                if((p%i) == 0)
                    break;
            }
            if(i==p)
                return 1;
            else 
                return 0;
        }
        
	public static void main(String[] args) throws UnknownHostException, IOException, NullPointerException
	{
                Scanner sc=new Scanner(System.in);
                int p , q , n , z , d = 0 , e , i ,flag = 1;
                
                
                /* creating new socket*/
                Socket socket = new Socket("localhost",2000);
                System.out.println("Connected");
                
               
                while(true)
                {
                    System.out.println("Enter 1st number p :");
                    p=sc.nextInt();
                    if(is_prime(p) == 1)   
                        break;   
                    else
                        System.out.println("Enter prime number");
                }
                
                 while(true)
                {
                    System.out.println("Enter 2nd number q :");
                    q=sc.nextInt();
                    if(is_prime(q) == 1)   
                        break;   
                    else
                        System.out.println("Enter prime number");
                }
               
                n=p*q;
                
                System.out.println("The value of n=p*q = "+n+"\n");
                z=(p-1)*(q-1);
                System.out.println("The value of phi =(p-1)*(q-1) ="+z+"\n");
                
                e=cal_e(z);
                d=cal_d(z,e);
                 
              
                System.out.println("Public Key Generated={e,n} = {"+e+","+n+"}"+"\n"+"Shared to server"+"\n");
                System.out.println("Private Key Generated={d,n}"+d+","+n+"\n");
                //Share public key
                PrintStream ps1  = new PrintStream(socket.getOutputStream());     
		ps1.println(e);
                PrintStream ps2  = new PrintStream(socket.getOutputStream());
                ps2.println(n);
                        
                //Get encrypted data
                DataInputStream d1=new DataInputStream(socket.getInputStream());
		String str1=d1.readLine();
                long C= Long.parseLong(str1);
                System.out.println("\nEncrypted text receieved is: "+C);
                Long D=decrypt(d, n, C);
                System.out.println("\nPlain text after decryption is:"+D);
                }
}
