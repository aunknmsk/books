#include<iostream>
#include<math.h>

using namespace std;

//considering:
//		a * x = 1 mod m

int inv(int a,int m)
{
	a=a%m;
	for(int x=1;x<m;x++)
		if((a*x)%m ==1)
			return x;
}
int main()
{
	int n;
	cout<<"Enter number of equations:";
	cin>>n;
	
	int a[n],m[n];
	for(int i=0;i<n;i++)
	{
		cout<<"Enter a"<<i+1<<": ";
		cin>>a[i];
		cout<<"Enter m"<<i+1<<": ";
		cin>>m[i];
	}
	
	//printing equations
	for(int i=0;i<n;i++)
	{
		cout<<"x = "<<a[i]<<" mod "<<m[i]<<endl;
	}
	
	//calculate the M
	int M = 1;
	for(int i=0;i<n;i++)
	{
		M *= m[i];
	}
	
	//Calculate the Mi values
	int Mi[n];
	for(int i=0;i<n;i++)
	{
		Mi[i] = M/m[i];
	}
	
	//Calculate the yi values
	int yi[n];
	for(int i=0;i<n;i++)
	{
		yi[i] = inv(Mi[i],m[i]);
	}
	
	// calculate the final value
	int x = 0;
	for(int i=0;i<n;i++)
	{
		x += a[i] * Mi[i] * yi[i];
	}
	x = x % M;
	cout<<"x = "<<x;
	return 0;
}
