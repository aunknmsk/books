
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
data=pd.read_csv("headbrain.csv")
#print(data)

X_train=data[:200]
#read first 200 values
#print(X_train)
#take values from 200 onwards
X_test=data[200:]
#print(X_test)
X=X_train['Head Size(cm^3)'].values
Y=X_train['Brain Weight(grams)'].values


#calculated mean of x and y
mean_x=np.mean(X)
mean_y=np.mean(Y)

print("Printing mean x")
print(mean_x)
print("Printing mean y")
print(mean_y)

#total number of values are taken in m
m=len(X)
print("Number of samples in training set")
print(m)
numer = 0
denom = 0
for i in range(m):
    numer+=(X[i] - mean_x) * (Y[i] - mean_y)
    denom+=(X[i] - mean_x) ** 2
#b1 is coefficient, b0 is bias
b1 = numer/denom
b0 = mean_y - (b1*mean_x)

print("Coefficient and bias is as follows")
print(b1, b0)


#plotting the graph
max_x = np.max(X)
min_x = np.min(X)

x = np.linspace(min_x, max_x)
y = b0 + b1*x

plt.plot(x, y, color='YELLOW', label='Regression Line')
plt.scatter(X, Y, c='GREEN', label='Scatter plot headsize vs brain wt')

plt.xlabel('Head Size in cm^3')
plt.ylabel('Brain weight in grams')
plt.legend()
plt.show()


sse = 0
for i in range(m):
    y_pred = b0 + b1 * X[i]
    sse += (Y[i] - y_pred) ** 2
    
print("Mean square error of brain wt of train data", sse)
mse = sse/m
rmse = np.sqrt(mse)
print("Root mean square error is", rmse)

ss_t = 0
ss_r = 0
for i in range(m):
    y_pred = b0 + b1 * X[i]
    ss_t += (Y[i] - mean_y) ** 2
    ss_r += (y_pred - mean_y) ** 2
scorer2 = 1 - (ss_r/ss_t)
print("R^2 score for training data is",scorer2)
